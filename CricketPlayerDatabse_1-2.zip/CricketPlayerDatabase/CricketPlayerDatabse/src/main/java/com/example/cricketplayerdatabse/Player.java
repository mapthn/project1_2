package com.example.cricketplayerdatabse;

import java.io.Serializable;

public class Player implements Serializable {
    private String name;
    private String country;
    private int age;
    private double height;
    private String club;
    private String position;
    private int jerseyno;
    private double salary;

    public Player() {

    }

    public Player(String name, String country, int age, double height, String club, String position, int jerseyno,
                  double salary) {
        this.name = name;
        this.country = country;
        this.age = age;
        this.height = height;
        this.club = club;
        this.position = position;
        this.jerseyno = jerseyno;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public String getClub() {
        return club;
    }

    public void setClub(String club) {
        this.club = club;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public int getJerseyno() {
        return jerseyno;
    }

    public void setJerseyno(int jerseyno) {
        this.jerseyno = jerseyno;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return "Player Info:\nName=" + name + "\nCountry=" + country + "\nAge=" + age + "\nHeight=" + height + "\nClub="
                + club + "\nPosition=" + position + "\nJerseyno=" + jerseyno + "\nSalary=" + salary + "\n"
                ;
    }

}
