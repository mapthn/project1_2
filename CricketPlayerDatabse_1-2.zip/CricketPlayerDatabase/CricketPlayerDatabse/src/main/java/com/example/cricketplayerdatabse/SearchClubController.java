package com.example.cricketplayerdatabse;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class SearchClubController {
    private Stage stage;
    private playerList playerlist;

    public void setList(playerList playerlist) {
        this.playerlist = playerlist;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void maxSalary(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/max-salary.fxml"));
            Parent root = loader.load();
            ClubPlayer controller = loader.getController();
            controller.setList(playerlist);


            controller.setStage(stage);

            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Search by club");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void maxAge(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/max-age.fxml"));
            Parent root = loader.load();
            ClubPlayer controller = loader.getController();
            controller.setList(playerlist);


            controller.setStage(stage);

            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Search by Club");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void maxHeight(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/max-height.fxml"));
            Parent root = loader.load();
            ClubPlayer controller = loader.getController();
            controller.setList(playerlist);


            controller.setStage(stage);

            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Search by Club");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void totalYearlySalary(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/total-yearly-salary.fxml"));
            Parent root = loader.load();
            ClubPlayer controller = loader.getController();
            controller.setList(playerlist);


            controller.setStage(stage);

            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Search by Club");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void backToMenu(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/main-menu.fxml"));
            Parent root = loader.load();


            MainMenuController controller = loader.getController();
            controller.setList(playerlist);

            controller.setStage(stage);
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Cricket Player Database");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
