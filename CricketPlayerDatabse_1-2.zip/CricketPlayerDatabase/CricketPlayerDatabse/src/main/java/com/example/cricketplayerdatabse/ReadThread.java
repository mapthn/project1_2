package com.example.cricketplayerdatabse;

import javafx.application.Platform;

import java.io.IOException;
import java.util.ArrayList;

public class ReadThread implements Runnable {
    private final Thread thr;
    private final Main main;
    playerList playerlist = new playerList();


    public ReadThread(Main main) {
        this.main = main;
        this.thr = new Thread(this);
        thr.start();
    }

    public void run() {
        try {
            Fileloading file = new Fileloading();
            file.readFromFile(playerlist);
            while (true) {
                Object o = main.getSocketWrapper().read();

                if (o != null) {
                    if (o instanceof LoginDTO) {
                        LoginDTO loginDTO = (LoginDTO) o;


                        Platform.runLater(new Runnable() {
                            @Override
                            public void run() {
                                if (loginDTO.isStatus()) {
                                    try {
                                        ArrayList<Player> players = new ArrayList<>();
                                        getPlayerDTO getDTO = new getPlayerDTO();
                                        getDTO.setClubName(loginDTO.getUserName());
                                        try {
                                            main.getSocketWrapper().write(getDTO);
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        }

                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                } else {
                                    LoginController.getInstance().inlabel.setVisible(true);
                                }

                            }
                        });
                    } else if (o instanceof getPlayerDTO) {

                        getPlayerDTO getDTO = (getPlayerDTO) o;
                        Platform.runLater(() -> {
                            try {
                                main.showHomePage(getDTO.getList());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        });


                    } else if (o instanceof buyDTO) {

                        Platform.runLater(() -> {
                            buyDTO response = (buyDTO) o;


                            main.setSellingList2(response.getList());
                        });

                    } else if (o instanceof buyDTO2) {
                        buyDTO2 response = (buyDTO2) o;

                        Platform.runLater(() -> {
                            try {
                                HomeController.getInstance().action(response.getList());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        });
                    } else if (o instanceof getListDTO) {
                        getListDTO response = (getListDTO) o;

                        Platform.runLater(() -> {
                            try {
                                main.setPlayerList(response.getPlayerList());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        });
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            try {
                main.getSocketWrapper().closeConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
