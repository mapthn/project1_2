package com.example.cricketplayerdatabse;

import java.io.Serializable;
import java.util.ArrayList;

public class getPlayerDTO implements Serializable {
    private String clubName;
    private ArrayList<Player> players = new ArrayList<>();

    void setClubName(String name) {
        clubName = name;
    }

    void setList(ArrayList<Player> players) {
        this.players = players;
    }

    String getClubName() {
        return clubName;
    }

    ArrayList<Player> getList() {
        return players;
    }

}
