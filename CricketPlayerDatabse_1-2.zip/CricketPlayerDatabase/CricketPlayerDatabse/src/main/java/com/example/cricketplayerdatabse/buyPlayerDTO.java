package com.example.cricketplayerdatabse;

import java.io.Serializable;

public class buyPlayerDTO implements Serializable {
    String name;

    public buyPlayerDTO(String name) {
        this.name = name;

    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}
