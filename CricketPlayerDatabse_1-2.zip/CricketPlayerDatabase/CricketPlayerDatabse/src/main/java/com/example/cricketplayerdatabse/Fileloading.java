package com.example.cricketplayerdatabse;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;


public class Fileloading {
    void readFromFile(playerList playerlist) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader("src/main/resources/players.txt"));
        String str;
        int lineNumber = 0;

        while ((str = br.readLine()) != null) {
            lineNumber++;
            str = str.trim();

            if (str.isEmpty()) {
                System.out.println("Skipping empty line at " + lineNumber);
                continue; // Skip empty lines
            }

            String[] info = str.split(",");
            if (info.length < 8) {
                System.out.println("Malformed line at " + lineNumber + ": " + str);
                continue;
            }

            try {
                String name = info[0].trim();
                String country = info[1].trim();
                int age = Integer.parseInt(info[2].trim());
                double height = Double.parseDouble(info[3].trim());
                String club = info[4].trim();
                String position = info[5].trim();
                int number = Integer.parseInt(info[6].trim());
                double salary = Double.parseDouble(info[7].trim());

                Player player = new Player(name, country, age, height, club, position, number, salary);
                playerlist.addPlayer(player);
            } catch (NumberFormatException e) {
                System.out.println("Error parsing numeric data at line " + lineNumber + ": " + str);
            } catch (Exception e) {
                System.out.println("Unexpected error at line " + lineNumber + ": " + e.getMessage());
            }
        }
        br.close();
    }

    void readToFile(playerList playerlist) throws Exception {
        BufferedWriter writer = new BufferedWriter(new FileWriter("src/main/resources/players.txt"));

        for (Player player : playerlist.players) {
            String str = String.format("%s,%s,%d,%.2f,%s,%s,%d,%f",
                    player.getName(),
                    player.getCountry(),
                    player.getAge(),
                    player.getHeight(),
                    player.getClub(),
                    player.getPosition(),
                    player.getJerseyno(),
                    player.getSalary());
            writer.write(str);
            writer.newLine();
        }

        writer.close();
    }
}
