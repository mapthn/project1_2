package com.example.cricketplayerdatabse;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class SellBuyController {
    private Stage stage;
    ArrayList<Player> sellingList = new ArrayList<Player>();
    private Main main;
    private ArrayList<Player> clubPlayers = new ArrayList<>();
    HomeController controller = new HomeController();

    void setSellingList(ArrayList<Player> list) {
        this.sellingList = list;

        sellingListView.getItems().clear();


        for (Player player : sellingList) {
            sellingListView.getItems().add(player.toString());

        }
    }


    public SellBuyController() throws Exception {
    }

    void setStage(Stage stage, Main main) {
        this.stage = stage;
        this.main = main;

    }

    @FXML
    private TextField sellPlayer;

    @FXML
    private Label inlabel;

    @FXML
    private Label inlabel2;

    @FXML
    private ListView<String> sellingListView;

    private SocketWrapper socketWrapper;

    public void setSocketWrapper(SocketWrapper socketWrapper) {
        this.socketWrapper = socketWrapper;
    }

    public void call() throws IOException {
        String string = new String("Sell");
        socketWrapper.write(string);

    }


    public void sellPlayer() {
        String playerName = sellPlayer.getText();
        boolean flag = false;
        boolean flag2 = true;
        for (Player player : clubPlayers) {
            if (player.getName().equalsIgnoreCase(playerName)) {
                flag = true;
                break;
            }
        }
        for (Player player : sellingList) {
            if (player.getName().equalsIgnoreCase(playerName)) {
                flag2 = false;
                break;
            }
        }
        if (flag2 == false) {
            inlabel2.setVisible(true);
        } else if (flag == false) {
            inlabel.setVisible(true);

        } else {
            if (playerName != null && !playerName.isEmpty()) {

                SellDTO sellDTO = new SellDTO(playerName);

                try {


                    socketWrapper.write(sellDTO);

                    sellingList = main.getSellingList();


                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }


    }


    public void showHomePage(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/com/example/cricketplayerdatabse/home.fxml"));
        Parent root = loader.load();

        HomeController controller = loader.getController();
        this.controller = controller;
        Main.getInstance().setHomeController(controller);
        controller.init(clubPlayers);
        controller.setStage(stage, Main.getInstance());


        controller.setSocketWrapper(Main.getSocketWrapper());

        stage.setTitle("Home");
        stage.setScene(new Scene(root, 600, 400));
        stage.show();
    }

    public void setClubPlayers(ArrayList<Player> players) {
        this.clubPlayers = players;
    }
}


