package com.example.cricketplayerdatabse;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class HomeController {
    ArrayList<Player> players = new ArrayList<>();
    private Stage stage;
    SocketWrapper socketWrapper;
    private SellBuyController controller;
    private BuyController controller2;
    private Main main;
    private static HomeController instance;
    int flag;
    playerList playerlist = new playerList();

    public HomeController() throws Exception {
        instance = this;
    }

    public void init(ArrayList<Player> players) {
        this.players = players;
    }

    public static HomeController getInstance() {
        return instance;
    }

    public void setStage(Stage stage, Main main) {
        this.stage = stage;
        this.main = main;
    }

    void setSocketWrapper(SocketWrapper socketWrapper) {
        this.socketWrapper = socketWrapper;
    }

    SellBuyController getController() {
        return this.controller;
    }

    BuyController getController2() {
        return this.controller2;
    }


    public void showClubList(ActionEvent actionEvent) throws IOException {
        flag = 1;
        buyDTO2 buydto2 = new buyDTO2();
        socketWrapper.write(buydto2);

    }

    public void buyPlayer(ActionEvent actionEvent) throws IOException {
        flag = 2;
        buyDTO2 buydto2 = new buyDTO2();
        socketWrapper.write(buydto2);

    }


    public void sellPlayer(ActionEvent actionEvent) throws IOException {
        this.flag = 3;
        buyDTO2 buydto2 = new buyDTO2();
        socketWrapper.write(buydto2);

    }

    void action(ArrayList<Player> players) throws IOException {
        if (flag == 1) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/show-players.fxml"));
            Parent root = loader.load();
            ShowPlayersController controller = loader.getController();
            controller.updatePlayerList(players);
            controller.setStage(stage);
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Show PlayerList");
            stage.show();
        } else if (flag == 2) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/buy.fxml"));
            Parent root = loader.load();
            BuyController controller = loader.getController();
            this.controller2 = controller;
            controller.setStage(stage);
            controller.setSocketWrapper(socketWrapper);
            controller.setClubPlayers(players);
            controller.call();


            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Buy Player");
            stage.show();
        } else if (flag == 3) {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/sell-buy.fxml"));
            Parent root = loader.load();
            SellBuyController controller = loader.getController();
            this.controller = controller;
            controller.setStage(stage, this.main);
            controller.setSocketWrapper(socketWrapper);
            controller.setClubPlayers(players);
            controller.call();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Sell Player");
            stage.show();
        }


    }


    public void backToMenu(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/main-menu.fxml"));
            Parent root = loader.load();

            Fileloading file = new Fileloading();
            file.readFromFile(playerlist);
            MainMenuController controller = loader.getController();
            controller.setList(playerlist);

            controller.setStage(stage);
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Cricket Player Database");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


}
