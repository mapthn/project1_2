package com.example.cricketplayerdatabse;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.control.ListView;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class BuyController {
    private Stage stage;
    ArrayList<Player> sellingList = new ArrayList<Player>();
    private SocketWrapper socketWrapper;
    ArrayList<Player> clubPlayers = new ArrayList<>();

    public void setSocketWrapper(SocketWrapper socketWrapper) {
        this.socketWrapper = socketWrapper;
    }

    void setStage(Stage stage) {
        this.stage = stage;

    }

    @FXML
    private ListView<String> sellViewList;
    @FXML
    private TextField buyPlayer;
    @FXML
    private Label inlabel1;
    @FXML
    private Label inlabel2;
    @FXML
    private Label inlabel3;
    @FXML
    private Button buy;

    public void call() throws IOException {
        String string = new String("Buy");
        socketWrapper.write(string);

    }


    public void setSellingList(ArrayList<Player> list) {
        this.sellingList = list;


        sellViewList.getItems().clear();
        for (Player player : sellingList) {
            sellViewList.getItems().add(player.toString());
        }
    }

    @FXML
    public void buyPlayer(ActionEvent actionEvent) throws IOException {
        String playerName = buyPlayer.getText();
        boolean flag1 = true;
        boolean flag2 = false;
        for (Player player : clubPlayers) {
            if (player.getName().equalsIgnoreCase(playerName)) {
                flag1 = false;
                break;
            }
        }
        for (Player player : sellingList) {
            if (player.getName().equalsIgnoreCase(playerName)) {
                flag2 = true;
                break;
            }
        }
        if (flag1 == false) {
            inlabel1.setVisible(true);
        } else if (flag2 == false) {
            inlabel2.setVisible(true);
        } else {
            buyPlayerDTO buyplayer = new buyPlayerDTO(playerName);
            socketWrapper.write(buyplayer);
            inlabel3.setVisible(true);

        }


    }

    public void showHomePage(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/com/example/cricketplayerdatabse/home.fxml"));
        Parent root = loader.load();

        HomeController controller = loader.getController();

        Main.getInstance().setHomeController(controller);
        controller.init(clubPlayers);
        controller.setStage(stage, Main.getInstance());


        controller.setSocketWrapper(Main.getSocketWrapper());

        stage.setTitle("Home");
        stage.setScene(new Scene(root, 600, 400));
        stage.show();
    }

    public void setClubPlayers(ArrayList<Player> players) {
        this.clubPlayers = players;
    }
}
