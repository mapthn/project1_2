package com.example.cricketplayerdatabse;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class ClubPlayer {
    private Stage stage;
    private playerList playerlist;
    @FXML
    private TextField nameField;
    @FXML
    private TextArea resultArea;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void setList(playerList playerlist) {
        this.playerlist = playerlist;
        String club = nameField.getText();


    }

    public void maxAge() {
        String club = nameField.getText();
        resultArea.setText("Please enter a valid club name.");
        boolean flag = false;
        for (Player player : playerlist.players) {
            if (player.getClub().equalsIgnoreCase(club)) {
                flag = true;
                break;
            }
        }
        if (flag) {
            Player player = playerlist.maxAge(club);
            StringBuilder result = new StringBuilder();
            result.append(player.toString()).append("\n");

            resultArea.setText(result.toString());
        } else {
            resultArea.setText("No Such Club Found.Go Back And Try Again");
        }

    }

    public void maxSalary() {
        String club = nameField.getText();
        resultArea.setText("Please enter a valid club name.");


        boolean flag = false;
        for (Player player : playerlist.players) {
            if (player.getClub().equalsIgnoreCase(club)) {
                flag = true;
                break;
            }
        }
        if (flag) {
            Player player = playerlist.maxSalary(club);
            StringBuilder result = new StringBuilder();
            result.append(player.toString()).append("\n");

            resultArea.setText(result.toString());
        } else {
            resultArea.setText("No Such Club Found.Go Back And Try Again");
        }
    }

    public void maxHeight() {
        String club = nameField.getText();
        resultArea.setText("Please enter a valid club name.");
        boolean flag = false;
        for (Player player : playerlist.players) {
            if (player.getClub().equalsIgnoreCase(club)) {
                flag = true;
                break;
            }
        }
        if (flag) {
            Player player = playerlist.maxHeight(club);
            StringBuilder result = new StringBuilder();
            result.append(player.toString()).append("\n");

            resultArea.setText(result.toString());
        } else {
            resultArea.setText("No Such Club Found.Go Back And Try Again");
        }


    }

    public void totalYearlySalary() {
        String club = nameField.getText();
        resultArea.setText("Please enter a valid club name.");
        boolean flag = false;
        for (Player player : playerlist.players) {
            if (player.getClub().equalsIgnoreCase(club)) {
                flag = true;
                break;
            }
        }
        if (flag) {
            Double value = playerlist.totalYearlySalary(club);


            resultArea.setText(String.valueOf(value));

        } else {
            resultArea.setText("No Such Club Found.Go Back And Try Again");
        }


    }

    public void back(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/search-club.fxml"));
            Parent root = loader.load();


            SearchClubController controller = loader.getController();
            controller.setList(playerlist);

            controller.setStage(stage);
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Search by Club");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
