package com.example.cricketplayerdatabse;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class MainMenuController {
    private Stage stage;

    private Main main;
    playerList playerlist = new playerList();

    public void setList(playerList playerlist) {

    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void setMain(Main main) {
        this.main = main;
    }

    public void searchPlayer(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/search-players.fxml"));
            Parent root = loader.load();
            SearchPlayerController controller = loader.getController();
            Fileloading file = new Fileloading();
            file.readFromFile(playerlist);

            controller.setList(playerlist);


            controller.setStage(stage);

            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Search by Player");
            stage.show();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void searchByClub(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/search-club.fxml"));
            Parent root = loader.load();
            SearchClubController controller = loader.getController();
            Fileloading file = new Fileloading();
            file.readFromFile(playerlist);
            controller.setList(playerlist);


            controller.setStage(stage);

            controller.setStage(stage);
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Search by Club");
            stage.show();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void addPlayer(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/add-player.fxml"));
            Parent root = loader.load();
            AddPlayerController controller = loader.getController();
            Fileloading file = new Fileloading();
            file.readFromFile(playerlist);

            controller.setList(playerlist);
            controller.setStage(stage);
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Add Player");
            stage.show();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public void exit(ActionEvent actionEvent) throws Exception {
        Fileloading file = new Fileloading();
        file.readFromFile(playerlist);

        Fileloading file2 = new Fileloading();
        file2.readToFile(playerlist);
        System.exit(0);
    }

    public void showLoginPage(ActionEvent actionEvent) throws IOException {
        if (this.main == null) {

        }
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/com/example/cricketplayerdatabse/login.fxml"));
        Parent root = loader.load();

        LoginController controller = loader.getController();

        controller.setStage(stage);
        controller.setMain(Main.getInstance());

        Scene scene = new Scene(root);
        stage.setTitle("Login");
        stage.setScene(scene);
        stage.show();
    }
}


