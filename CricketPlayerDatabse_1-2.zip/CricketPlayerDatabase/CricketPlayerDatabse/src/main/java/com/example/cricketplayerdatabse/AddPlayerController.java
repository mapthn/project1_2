package com.example.cricketplayerdatabse;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class AddPlayerController {
    private Stage stage;
    private playerList playerlist;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void setList(playerList playerlist) {
        this.playerlist = playerlist;
    }

    @FXML
    private TextField field1;
    @FXML
    private TextField field2;
    @FXML
    private TextField field3;
    @FXML
    private TextField field4;
    @FXML
    private TextField field5;
    @FXML
    private TextField field6;
    @FXML
    private TextField field7;
    @FXML
    private TextField field8;
    @FXML
    private Label label;
    @FXML
    private Label label1;


    public void addPlayer(ActionEvent actionEvent) throws Exception {
        boolean flag = true;
        String name = field1.getText();
        for (Player player : playerlist.players) {
            if (player.getName().equalsIgnoreCase(name)) {
                label.setVisible(true);

                flag = false;
            }
        }
        if (flag) {
            int age = Integer.parseInt(field2.getText());
            String country = field3.getText();
            Double height = Double.valueOf(field4.getText());
            String club = field5.getText();
            Double salary = Double.valueOf(field6.getText());
            int num = Integer.parseInt(field7.getText());
            String position = field8.getText();
            Player player = new Player(name, country, age, height, club, position, num, salary);
            playerlist.addPlayer(player);
            Fileloading file = new Fileloading();
            file.readToFile(playerlist);

            setListDTO setlist = new setListDTO();
            setlist.setList(playerlist.players);
            Main.getInstance().getSocketWrapper().write(setlist);
            label1.setVisible(true);

        }


    }

    public void back(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/main-menu.fxml"));
            Parent root = loader.load();


            MainMenuController controller = loader.getController();
            controller.setList(playerlist);

            controller.setStage(stage);
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Cricket Player Database");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
