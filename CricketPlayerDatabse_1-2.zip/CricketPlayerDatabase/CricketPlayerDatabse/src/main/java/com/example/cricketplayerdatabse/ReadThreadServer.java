package com.example.cricketplayerdatabse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

public class ReadThreadServer implements Runnable {
    private final Thread thr;
    private final SocketWrapper socketWrapper;
    public HashMap<String, String> userMap;
    ArrayList<Player> players = new ArrayList<>();
    ArrayList<Player> clubPlayers = new ArrayList<>();
    String club = new String();
    Server server = new Server();
    public static ArrayList<SocketWrapper> connectedClients = new ArrayList<>();

    public ReadThreadServer(HashMap<String, String> map, SocketWrapper socketWrapper, ArrayList<Player> players) throws Exception {
        this.userMap = map;
        this.players = server.getList();
        this.socketWrapper = socketWrapper;
        synchronized (connectedClients) {
            connectedClients.add(socketWrapper);
        }
        this.thr = new Thread(this);
        this.players = players;
        thr.start();
    }


    public void run() {
        try {
            while (true) {
                Object o = socketWrapper.read();

                if (o != null) {
                    if (o instanceof LoginDTO) {
                        LoginDTO loginDTO = (LoginDTO) o;
                        String password = userMap.get(loginDTO.getUserName());
                        loginDTO.setStatus(loginDTO.getPassword().equals(password));
                        socketWrapper.write(loginDTO);
                    }
                    if (o instanceof getPlayerDTO) {
                        new Thread(() -> {
                            getPlayerDTO getDTO = (getPlayerDTO) o;
                            String name = getDTO.getClubName();
                            this.club = name;
                            try {
                                this.players = server.getList();
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }

                            for (Player player : this.players) {
                                if (player.getClub().equalsIgnoreCase(name)) {
                                    clubPlayers.add(player);
                                }
                            }


                            getDTO.setList(clubPlayers);
                            server.setClubPlayers(clubPlayers);


                            try {
                                socketWrapper.write(getDTO);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                        }).start();

                    }
                    if (o instanceof SellDTO) {
                        new Thread(() -> {

                            SellDTO sellDTO = (SellDTO) o;

                            String playerName = sellDTO.getName();

                            Player playerToSell = new Player();
                            try {
                                this.players = server.getList();
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                            synchronized (players) {
                                for (Player player : players) {
                                    if (player.getName().equalsIgnoreCase(playerName)) {
                                        playerToSell = player;
                                        break;
                                    }
                                }
                            }
                            ArrayList<Player> sellingList = server.getSellingList();
                            synchronized (sellingList) {
                                if (playerToSell != null) {

                                    sellingList.add(playerToSell);
                                }
                            }


                            broadcastToAllClients();

                        }).start();
                    }
                    if (o instanceof String) {
                        new Thread(() -> {
                            ArrayList<Player> sellingList = server.getSellingList();
                            buyDTO response = new buyDTO();
                            response.setList(sellingList);
                            try {
                                socketWrapper.write(response);
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        }).start();
                    }
                    if (o instanceof buyPlayerDTO) {
                        new Thread(() -> {
                            buyPlayerDTO buyplayer = (buyPlayerDTO) o;
                            String name = buyplayer.getName();
                            try {
                                server.changeClub(this.club, name);
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }

                            try {
                                players = server.getList();
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                            ArrayList<Player> newList = new ArrayList<>();

                            for (Player player : players) {
                                if (player.getClub().equalsIgnoreCase(club)) {
                                    newList.add(player);
                                }
                            }

                            clubPlayers = newList;


                            server.setClubPlayers(clubPlayers);

                            broadcastToAllClients();


                        }).start();
                    }
                    if (o instanceof buyDTO2) {
                        new Thread(() -> {
                            buyDTO2 buydto2 = (buyDTO2) o;
                            try {
                                players = server.getList();
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                            ArrayList<Player> newList = new ArrayList<>();

                            for (Player player : players) {
                                if (player.getClub().equalsIgnoreCase(club)) {
                                    newList.add(player);
                                }
                            }

                            clubPlayers = newList;
                            buydto2.setList(clubPlayers);
                            try {
                                socketWrapper.write(buydto2);
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        }).start();
                    }
                    if (o instanceof setListDTO) {
                        new Thread(() -> {
                            setListDTO setlist = (setListDTO) o;
                            try {
                                server.setList(setlist.getList());
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                        }).start();
                    }
                    if (o instanceof getListDTO) {
                        new Thread(() -> {
                            getListDTO getlist = (getListDTO) o;
                            playerList newList = new playerList();
                            try {
                                newList.players = server.getList();
                            } catch (Exception e) {
                                throw new RuntimeException(e);
                            }
                            getlist.setPlayerList(newList);
                            try {
                                socketWrapper.write(getlist);
                            } catch (IOException e) {
                                throw new RuntimeException(e);
                            }
                        }).start();
                    }
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            try {
                socketWrapper.closeConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void broadcastToAllClients() {
        synchronized (connectedClients) {
            ArrayList<Player> sellingList = server.getSellingList();
            for (SocketWrapper client : connectedClients) {
                try {
                    buyDTO update = new buyDTO();
                    update.setList(sellingList);
                    client.write(update);
                } catch (IOException e) {
                    System.out.println("Failed to send update to a client: " + e.getMessage());
                }
            }
        }
    }
}
