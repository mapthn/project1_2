package com.example.cricketplayerdatabse;

import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;

public class Server {
    private ServerSocket serverSocket;
    public HashMap<String, String> userMap;
    public ArrayList<Player> players = new ArrayList<>();
    public playerList playerlist = new playerList();
    private static ArrayList<Player> sellingList = new ArrayList<>();
    private ArrayList<Player> clubPlayers = new ArrayList<>();


    void setList(ArrayList<Player> players) throws Exception {
        this.players = players;
        this.playerlist.players = players;
        Fileloading file = new Fileloading();
        file.readToFile(playerlist);

    }

    ArrayList<Player> getList() throws Exception {
        playerlist = new playerList();
        players = new ArrayList<>();
        Fileloading file = new Fileloading();
        file.readFromFile(playerlist);
        players = playerlist.players;
        return players;
    }

    Server() throws Exception {
        userMap = new HashMap<>();
        userMap.put("Royal Challengers Bangalore", "rcb");
        userMap.put("Kolkata Knight Riders", "kkr");
        userMap.put("Chennai Super Kings", "csk");
        userMap.put("Mumbai Indians", "mi");
        userMap.put("Rajasthan Royals", "rr");
        userMap.put("Delhi Capitals", "dc");
        userMap.put("Gujarat Titans", "gt");
        userMap.put("Lucknow Super Giants", "lsg");
        userMap.put("Punjab Kings", "pk");
        userMap.put("Sunrisers Hyderabad", "sh");
        Fileloading file = new Fileloading();
        file.readFromFile(playerlist);
        this.players = playerlist.players;


        try {
            serverSocket = new ServerSocket(33333);
            while (true) {
                Socket clientSocket = serverSocket.accept();
                serve(clientSocket);
            }
        } catch (Exception e) {
            System.out.println("Server starts:" + e);
        }
    }


    public void serve(Socket clientSocket) throws Exception {
        SocketWrapper socketWrapper = new SocketWrapper(clientSocket);
        new ReadThreadServer(userMap, socketWrapper, players);
    }

    public void setSellingList(ArrayList<Player> players) {
        this.sellingList = players;
    }

    ArrayList<Player> getSellingList() {
        return this.sellingList;
    }

    void setClubPlayers(ArrayList<Player> players) {

        clubPlayers = players;

    }

    void changeClub(String club, String name) throws Exception {

        Player target = null;
        for (Player player : players) {
            if (player.getName().equalsIgnoreCase(name)) {
                target = player;

                System.out.println("Successfully server updated");
                break;
            }
        }
        if (target != null) {
            int idx = -1;
            for (int i = 0; i < sellingList.size(); i++) {
                if (sellingList.get(i).getName().equalsIgnoreCase(target.getName())) {
                    idx = i;
                    break;
                }
            }
            sellingList.remove(idx);

        }
        if (target != null) {
            int idx = -1;
            for (int i = 0; i < players.size(); i++) {
                if (players.get(i).getName().equalsIgnoreCase(target.getName())) {
                    idx = i;
                    break;
                }
            }
            players.remove(idx);


        }
        target.setClub(club);

        players.add(target);

        playerlist.players = players;
        Fileloading file = new Fileloading();
        file.readToFile(playerlist);


    }

    public static void main(String[] args) throws Exception {
        new Server();
    }
}
