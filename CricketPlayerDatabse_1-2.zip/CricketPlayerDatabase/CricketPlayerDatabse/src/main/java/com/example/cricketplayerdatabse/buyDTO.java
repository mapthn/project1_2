package com.example.cricketplayerdatabse;

import java.io.Serializable;
import java.util.ArrayList;

public class buyDTO implements Serializable {
    private ArrayList<Player> list;

    void setList(ArrayList<Player> list) {
        this.list = list;
    }

    ArrayList<Player> getList() {
        return list;
    }
}
