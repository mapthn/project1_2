package com.example.cricketplayerdatabse;

import java.io.Serializable;
import java.util.ArrayList;

import java.util.ArrayList;

public class playerList implements Serializable {

    ArrayList<Player> players = new ArrayList<>();

    void addPlayer(Player player) {
        players.add(player);
    }

    void displayPlayers(ArrayList<Player> players) {
        if (players == null) {
            System.out.println("No such player found");
        } else {
            for (Player p : players) {
                System.out.println(p);
            }
        }


    }

    ArrayList<Player> searchByName(String name) {
        ArrayList<Player> list = new ArrayList<>();
        for (Player player : players) {
            if (player.getName().equalsIgnoreCase(name)) {
                list.add(player);
                return list;
            }
        }
        return list;
    }

    ArrayList<Player> searchByCountry(String country, String club) {
        ArrayList<Player> list = new ArrayList<>();
        int flag = 0;
        if (club.trim().equalsIgnoreCase("any")) {
            for (Player player : players) {
                if (player.getCountry().equalsIgnoreCase(country)) {
                    list.add(player);
                    flag++;
                }
            }
        } else {
            for (Player player : players) {
                if (player.getCountry().equalsIgnoreCase(country) && player.getClub().equalsIgnoreCase(club)) {
                    list.add(player);
                    flag++;
                }
            }
        }
        if (flag == 0) {
            return list;
        } else {
            return list;
        }
    }

    ArrayList<Player> searchByPosition(String position) {
        ArrayList<Player> list = new ArrayList<>();
        int flag = 0;
        for (Player player : players) {
            if (player.getPosition().equalsIgnoreCase(position)) {
                list.add(player);
                flag++;
            }
        }
        if (flag == 0)
            return list;
        else {
            return list;
        }
    }

    ArrayList<Player> searchBySalary(double low, double high) {
        ArrayList<Player> list = new ArrayList<>();
        int flag = 0;
        for (Player player : players) {
            if (player.getSalary() >= low && player.getSalary() <= high) {
                list.add(player);
                flag++;
            }
        }
        if (flag == 0) {
            return list;
        } else {
            return list;
        }
    }

    Player maxSalary(String club) {
        double max = 0;
        int idx = -1;
        for (int i = 0; i < players.size(); i++) {
            if (players.get(i).getClub().equalsIgnoreCase(club)) {
                if (players.get(i).getSalary() > max) {
                    max = players.get(i).getSalary();
                    idx = i;
                }
            }
        }
        return players.get(idx);

    }

    Player maxAge(String club) {
        int max = 0;
        int idx = -1;
        for (int i = 0; i < players.size(); i++) {
            if (players.get(i).getClub().equalsIgnoreCase(club)) {
                if (players.get(i).getAge() > max) {
                    max = players.get(i).getAge();
                    idx = i;
                }
            }
        }
        return players.get(idx);

    }

    Player maxHeight(String club) {
        double max = 0;
        int idx = -1;
        for (int i = 0; i < players.size(); i++) {
            if (players.get(i).getClub().equalsIgnoreCase(club)) {
                if (players.get(i).getHeight() > max) {
                    max = players.get(i).getHeight();
                    idx = i;
                }
            }
        }
        return players.get(idx);

    }

    double totalYearlySalary(String club) {
        double sum = 0;
        for (Player player : players) {
            if (player.getClub().equalsIgnoreCase(club)) {
                sum += player.getSalary() * 52;
            }
        }

        return sum;

    }
}
