package com.example.cricketplayerdatabse;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class SearchBySalaryController {
    private Stage stage;
    private playerList playerlist;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void setList(playerList playerlist) {
        this.playerlist = playerlist;
    }

    @FXML
    private TextField nameField1;
    @FXML
    private TextField nameField2;


    @FXML
    private TextArea resultArea;

    public void searchBySalary() {
        Double low = Double.valueOf(nameField1.getText().trim());
        Double high = Double.valueOf(nameField2.getText().trim());

       /* if (country.isEmpty()) {
            resultArea.setText("Please enter a valid player name.");
            return;
        }*/


        ArrayList<Player> players = playerlist.searchBySalary(low, high);


        if (players.isEmpty()) {
            resultArea.setText("No players found with the salary range: " + low + " to " + high);
        } else {

            StringBuilder result = new StringBuilder("Players found:\n");
            for (Player player : players) {
                result.append(player.toString()).append("\n");
            }
            resultArea.setText(result.toString());
        }
    }

    public void back(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/search-players.fxml"));
            Parent root = loader.load();


            SearchPlayerController controller = loader.getController();
            controller.setList(playerlist);

            controller.setStage(stage);
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Search by Player");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
