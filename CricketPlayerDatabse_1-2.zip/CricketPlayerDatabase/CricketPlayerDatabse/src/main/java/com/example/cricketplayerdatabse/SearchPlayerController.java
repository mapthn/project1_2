package com.example.cricketplayerdatabse;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class SearchPlayerController {

    private Stage stage;
    private playerList playerlist;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public void setList(playerList playerlist) {
        this.playerlist = playerlist;
    }


    public void searchByName(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/search-by-name.fxml"));
            Parent root = loader.load();
            SearchByNameController controller = loader.getController();
            controller.setList(playerlist);

            controller.setStage(stage);
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Search by Name");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Search by country and club
    public void searchByCountryClub(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/search-by-country.fxml"));
            Parent root = loader.load();
            SearchByCountryController controller = loader.getController();
            controller.setList(playerlist);


            controller.setStage(stage);
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Search by Country");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void searchByPosition(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/search-by-position.fxml"));
            Parent root = loader.load();
            SearchByPositionController controller = loader.getController();
            controller.setList(playerlist);


            controller.setStage(stage);
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Search by Position");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public void backToMainMenu(ActionEvent actionEvent) {

        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/main-menu.fxml"));
            Parent root = loader.load();


            MainMenuController controller = loader.getController();
            controller.setList(playerlist);

            controller.setStage(stage);
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Cricket Player Databse");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void searchBySalary(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/search-by-salary.fxml"));
            Parent root = loader.load();
            SearchBySalaryController controller = loader.getController();
            controller.setList(playerlist);


            controller.setStage(stage);
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Search by Salary");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void playerCount(ActionEvent actionEvent) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/cricketplayerdatabse/player-count.fxml"));
            Parent root = loader.load();
            PlayerCountController controller = loader.getController();
            controller.setList(playerlist);


            controller.setStage(stage);

            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Player Count");
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
