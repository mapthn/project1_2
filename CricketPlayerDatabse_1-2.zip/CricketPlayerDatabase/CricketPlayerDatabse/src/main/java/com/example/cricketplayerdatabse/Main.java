package com.example.cricketplayerdatabse;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ArrayList;

public class Main extends Application {
    playerList playerlist = new playerList();
    private Stage stage;
    private static SocketWrapper socketWrapper;
    private static HomeController controller;
    private SellBuyController cntrllar;
    private BuyController cntrllar2;
    ArrayList<Player> sellingList = new ArrayList<>();
    ArrayList<Player> players = new ArrayList<>();
    private static Main instance;


    public Main() throws Exception {
        instance = this;
    }

    public static Main getInstance() {
        return instance;
    }

    public static SocketWrapper getSocketWrapper() {
        return socketWrapper;
    }


    public void setSellingList(ArrayList<Player> players) {
        cntrllar = controller.getController();
        cntrllar.setSellingList(players);
        this.sellingList = players;

    }

    public void setSellingList2(ArrayList<Player> players) {
        cntrllar2 = controller.getController2();
        cntrllar = controller.getController();
        this.sellingList = players;
        if (cntrllar2 != null) {
            cntrllar2.setSellingList(players);
        } else if (cntrllar != null) {
            cntrllar.setSellingList(players);
        }

    }

    void setHomeController(HomeController controller) {
        this.controller = controller;
    }

    ArrayList<Player> getSellingList() {
        return this.sellingList;
    }

    void setPlayerList(playerList list) {

        this.playerlist = list;
        players = playerlist.players;
    }

    @Override
    public void start(Stage primaryStage) throws Exception {

        this.stage = primaryStage;
        String serverAddress = "127.0.0.1";
        int serverPort = 33333;
        socketWrapper = new SocketWrapper(serverAddress, serverPort);
        new ReadThread(this);
        getListDTO getlist = new getListDTO();
        socketWrapper.write(getlist);


        URL fxmlLocation = getClass().getResource("/main-menu.fxml");
        System.out.println("FXML Location: " + fxmlLocation);

        if (fxmlLocation == null) {
            throw new RuntimeException("FXML file not found! Check path.");
        }

        FXMLLoader loader = new FXMLLoader(fxmlLocation);
        Parent root = loader.load();


        MainMenuController controller = loader.getController();

        controller.setMain(this);

        controller.setStage(stage);

        stage.setTitle("Cricket Player Database");
        stage.setScene(new Scene(root, 594, 461));
        stage.show();

    }


    public void showHomePage(ArrayList<Player> players) throws Exception {

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/com/example/cricketplayerdatabse/home.fxml"));
        Parent root = loader.load();

        HomeController controller = loader.getController();
        this.controller = controller;

        controller.init(players);
        controller.setStage(stage, this);


        controller.setSocketWrapper(socketWrapper);

        stage.setTitle("Login Home");
        stage.setScene(new Scene(root, 600, 400));
        stage.show();
    }

    public static void main(String[] args) throws Exception {

        launch(args);
    }


}
