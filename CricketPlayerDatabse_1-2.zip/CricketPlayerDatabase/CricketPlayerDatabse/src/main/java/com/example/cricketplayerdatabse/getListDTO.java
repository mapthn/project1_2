package com.example.cricketplayerdatabse;

import java.io.Serializable;

public class getListDTO implements Serializable {
    private playerList playerlist = new playerList();

    void setPlayerList(playerList playerlist) {
        this.playerlist = playerlist;
    }

    playerList getPlayerList() {
        return playerlist;
    }
}
