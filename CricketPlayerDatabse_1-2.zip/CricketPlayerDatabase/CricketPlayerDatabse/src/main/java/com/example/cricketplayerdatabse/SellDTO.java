package com.example.cricketplayerdatabse;

import java.io.Serializable;

public class SellDTO implements Serializable {
    String name;

    public SellDTO(String name) {
        this.name = name;

    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

}
