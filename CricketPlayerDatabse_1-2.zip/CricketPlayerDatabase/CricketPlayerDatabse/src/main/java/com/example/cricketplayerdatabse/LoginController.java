package com.example.cricketplayerdatabse;


import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController {
    private Main main;
    private Stage stage;
    @FXML
    private TextField userText;
    @FXML
    private PasswordField passwordText;

    @FXML
    private Button loginButton;
    private static LoginController instance;

    public static LoginController getInstance() {
        return instance;
    }

    public LoginController() {
        instance = this;
    }

    @FXML
    Label inlabel;

    @FXML
    void loginAction(ActionEvent event) {
        String userName = this.userText.getText();
        String password = this.passwordText.getText();
        LoginDTO loginDTO = new LoginDTO();
        loginDTO.setUserName(userName);
        loginDTO.setPassword(password);

        try {
            this.main.getSocketWrapper().write(loginDTO);
        } catch (IOException var6) {
            IOException e = var6;
            e.printStackTrace();
        }

    }


    void setMain(Main main) {
        this.main = main;
    }

    void setStage(Stage stage) {
        this.stage = stage;
    }

    public void backToHome(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/main-menu.fxml"));
        Parent root = loader.load();


        MainMenuController controller = loader.getController();


        controller.setStage(stage);
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Cricket Player Database");
        stage.show();


    }
}
