package com.example.cricketplayerdatabse;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class ShowPlayersController {
    ArrayList<Player> players = new ArrayList<>();
    HomeController controller = new HomeController();

    private Stage stage;

    public ShowPlayersController() throws Exception {
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private TableView<Player> playerTable;
    @FXML
    private TableColumn<Player, String> nameColumn;
    @FXML
    private TableColumn<Player, String> countryColumn;
    @FXML
    private TableColumn<Player, String> clubColumn;
    @FXML
    private TableColumn<Player, Integer> ageColumn;
    @FXML
    private TableColumn<Player, Double> salaryColumn;
    @FXML
    private TableColumn<Player, Double> heightColumn;
    @FXML
    private TableColumn<Player, String> positionColumn;
    @FXML
    private TableColumn<Player, Integer> jerseyColumn;

    public void initialize() {
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        countryColumn.setCellValueFactory(new PropertyValueFactory<>("country"));
        clubColumn.setCellValueFactory(new PropertyValueFactory<>("club"));
        ageColumn.setCellValueFactory(new PropertyValueFactory<>("age"));
        salaryColumn.setCellValueFactory(new PropertyValueFactory<>("salary"));
        heightColumn.setCellValueFactory(new PropertyValueFactory<>("height"));
        positionColumn.setCellValueFactory(new PropertyValueFactory<>("position"));
        jerseyColumn.setCellValueFactory(new PropertyValueFactory<>("jerseyno"));
    }


    public void updatePlayerList(ArrayList<Player> playerList) {
        playerTable.getItems().clear();
        ObservableList<Player> observablePlayerList = FXCollections.observableArrayList(playerList);
        this.players = playerList;

        playerTable.setItems(observablePlayerList);
    }

    public void showHomePage(ActionEvent actionEvent) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/com/example/cricketplayerdatabse/home.fxml"));
        Parent root = loader.load();


        HomeController controller = loader.getController();
        this.controller = controller;
        Main.getInstance().setHomeController(controller);
        controller.init(players);
        controller.setStage(stage, Main.getInstance());


        controller.setSocketWrapper(Main.getSocketWrapper());

        stage.setTitle("Home");
        stage.setScene(new Scene(root, 600, 400));
        stage.show();
    }
}
