module com.example.cricketplayerdatabse {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.cricketplayerdatabse to javafx.fxml;
    exports com.example.cricketplayerdatabse;
}